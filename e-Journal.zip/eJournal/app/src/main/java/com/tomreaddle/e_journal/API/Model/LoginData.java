package com.tomreaddle.e_journal.API.Model;

public class LoginData {

    String email;
    String password;

    public LoginData(String email, String password) {
        this.email = email;
        this.password = password;
    }
}
