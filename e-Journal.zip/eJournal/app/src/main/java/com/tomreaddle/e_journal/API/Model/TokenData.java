package com.tomreaddle.e_journal.API.Model;

public class TokenData {

    String token;

    public void setToken(String token) {
        this.token = token;
    }

    public String getToken() {
        return token;
    }
}
